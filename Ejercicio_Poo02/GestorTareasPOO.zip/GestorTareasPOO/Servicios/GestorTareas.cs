﻿using GestorTareasPOO.Modelos;

namespace GestorTareasPOO.Servicios
{
    public class GestorTareas
    {
        private List<Tarea> tareas;

        public GestorTareas()
        {
            tareas = new List<Tarea>();
        }

        public void Agregar(Tarea tarea)
        {
            tareas.Add(tarea);
        }

        public List<Tarea> ListarTodas()
        {
            return tareas;
        }

        public List<Tarea> ListarPorCategoria(string categoria)
        {
            return tareas
                .Where(t => t.Categoria != null &&
                            t.Categoria.Nombre.Equals(categoria, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        public List<Tarea> ListarPorPrioridad(Prioridad prioridad)
        {
            return tareas
                .Where(t => t.Prioridad == prioridad)
                .ToList();
        }

        public void Completar(int id)
        {
            Tarea tarea = tareas.FirstOrDefault(t => t.Id == id);

            if (tarea != null)
            {
                tarea.Completada = true;
            }
        }

        public List<Tarea> ObtenerVencidas()
        {
            return tareas
                .Where(t =>
                    t is TareaConVencimiento tv &&
                    tv.FechaVencimiento < DateTime.Now &&
                    !tv.Completada)
                .ToList();
        }

        public void Eliminar(int id)
        {
            Tarea tarea = tareas.FirstOrDefault(t => t.Id == id);

            if (tarea != null)
            {
                tareas.Remove(tarea);
            }
        }
    }
}