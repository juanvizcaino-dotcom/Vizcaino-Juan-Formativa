﻿using GestorTareasPOO.Modelos;
using GestorTareasPOO.Servicios;

GestorTareas gestor = new GestorTareas();

int opcion;

do
{
    Console.Clear();

    Console.WriteLine("===== GESTOR DE TAREAS =====");
    Console.WriteLine("1. Agregar tarea");
    Console.WriteLine("2. Listar todas");
    Console.WriteLine("3. Listar por categoría");
    Console.WriteLine("4. Listar por prioridad");
    Console.WriteLine("5. Marcar como completada");
    Console.WriteLine("6. Mostrar tareas vencidas");
    Console.WriteLine("7. Eliminar tarea");
    Console.WriteLine("8. Exportar a JSON");
    Console.WriteLine("9. Salir");
    Console.Write("\nSeleccione una opción: ");

    opcion = int.Parse(Console.ReadLine());

    switch (opcion)
    {
        case 1:
            Console.Write("Título: ");
            string titulo = Console.ReadLine();

            Console.Write("Descripción: ");
            string descripcion = Console.ReadLine();

            Console.WriteLine("\nPrioridad:");
            Console.WriteLine("1. Baja");
            Console.WriteLine("2. Media");
            Console.WriteLine("3. Alta");
            Console.WriteLine("4. Crítica");

            int opcionPrioridad = int.Parse(Console.ReadLine());

            Prioridad prioridad = (Prioridad)(opcionPrioridad - 1);

            Console.Write("Nombre de la categoría: ");
            string nombreCategoria = Console.ReadLine();

            Console.Write("Color de la categoría: ");
            string colorCategoria = Console.ReadLine();

            Console.Write("Descripción de la categoría: ");
            string descripcionCategoria = Console.ReadLine();

            Categoria categoria = new Categoria
            {
                Nombre = nombreCategoria,
                Color = colorCategoria,
                Descripcion = descripcionCategoria
            };

            Console.Write("¿Tiene fecha de vencimiento? (S/N): ");
            string respuesta = Console.ReadLine().ToUpper();

            if (respuesta == "S")
            {
                Console.Write("Fecha de vencimiento (dd/MM/yyyy): ");
                DateTime fecha = DateTime.Parse(Console.ReadLine());

                TareaConVencimiento tarea = new TareaConVencimiento
                {
                    Titulo = titulo,
                    Descripcion = descripcion,
                    Prioridad = prioridad,
                    Categoria = categoria,
                    FechaVencimiento = fecha
                };

                gestor.Agregar(tarea);
            }
            else
            {
                Tarea tarea = new Tarea
                {
                    Titulo = titulo,
                    Descripcion = descripcion,
                    Prioridad = prioridad,
                    Categoria = categoria
                };

                gestor.Agregar(tarea);
            }

            Console.WriteLine("\nTarea agregada correctamente.");
            break;

        case 2:

            List<Tarea> lista = gestor.ListarTodas();

            if (lista.Count == 0)
            {
                Console.WriteLine("\nNo hay tareas registradas.");
            }
            else
            {
                foreach (Tarea tarea in lista)
                {
                    tarea.MostrarInfo();
                    Console.WriteLine("---------------------------");
                }
            }

            break;

        case 3:

            Console.Write("Ingrese el nombre de la categoría: ");
            string categoriaBuscar = Console.ReadLine();

            List<Tarea> tareasCategoria = gestor.ListarPorCategoria(categoriaBuscar);

            if (tareasCategoria.Count == 0)
            {
                Console.WriteLine("\nNo se encontraron tareas.");
            }
            else
            {
                foreach (Tarea tarea in tareasCategoria)
                {
                    tarea.MostrarInfo();
                    Console.WriteLine("---------------------------");
                }
            }

            break;

        case 4:

            Console.WriteLine("Seleccione la prioridad:");
            Console.WriteLine("1. Baja");
            Console.WriteLine("2. Media");
            Console.WriteLine("3. Alta");
            Console.WriteLine("4. Crítica");

            int p = int.Parse(Console.ReadLine());

            Prioridad prioridadBuscar = (Prioridad)(p - 1);

            List<Tarea> tareasPrioridad = gestor.ListarPorPrioridad(prioridadBuscar);

            if (tareasPrioridad.Count == 0)
            {
                Console.WriteLine("\nNo se encontraron tareas.");
            }
            else
            {
                foreach (Tarea tarea in tareasPrioridad)
                {
                    tarea.MostrarInfo();
                    Console.WriteLine("---------------------------");
                }
            }

            break;

        case 5:

            Console.Write("Ingrese el ID de la tarea: ");
            int idCompletar = int.Parse(Console.ReadLine());

            gestor.Completar(idCompletar);

            Console.WriteLine("\nTarea marcada como completada.");

            break;

        case 6:

            List<Tarea> vencidas = gestor.ObtenerVencidas();

            if (vencidas.Count == 0)
            {
                Console.WriteLine("\nNo hay tareas vencidas.");
            }
            else
            {
                foreach (Tarea tarea in vencidas)
                {
                    tarea.MostrarInfo();
                    Console.WriteLine("---------------------------");
                }
            }

            break;

        case 7:

            Console.Write("Ingrese el ID de la tarea: ");
            int idEliminar = int.Parse(Console.ReadLine());

            gestor.Eliminar(idEliminar);

            Console.WriteLine("\nTarea eliminada.");

            break;

        case 8:
            Console.WriteLine("Exportar JSON");
            break;
    }

    if (opcion != 9)
    {
        Console.WriteLine("\nPresione una tecla para continuar...");
        Console.ReadKey();
    }

} while (opcion != 9);